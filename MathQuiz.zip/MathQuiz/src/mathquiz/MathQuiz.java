package mathquiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class MathQuiz extends JFrame {
    private JLabel questionLabel;
    private JTextField answerField;
    private JButton submitButton;
    private JLabel scoreLabel;
    private JLabel timerLabel;
    private int score = 0;
    private int timeLeft = 30;
    private Timer timer;
    private int correctAnswer;
    private int difficulty = 10;

    public MathQuiz() {
        setupGame();
        setupMenu();
    }

    // Metode untuk mengatur menu awal
    private void setupMenu() {
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Selamat Datang di Kuis Matematika");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton easyButton = new JButton("Mudah");
        JButton mediumButton = new JButton("Sedang");
        JButton hardButton = new JButton("Sulit");

        easyButton.addActionListener(e -> startGame(10, 30));
        mediumButton.addActionListener(e -> startGame(50, 20));
        hardButton.addActionListener(e -> startGame(100, 15));

        menuPanel.add(titleLabel);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        menuPanel.add(easyButton);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        menuPanel.add(mediumButton);
        menuPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        menuPanel.add(hardButton);

        add(menuPanel);
    }

    // Metode untuk mengatur GUI utama permainan
    private void setupGame() {
        questionLabel = new JLabel("Soal akan muncul di sini", JLabel.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        questionLabel.setForeground(Color.BLUE);

        answerField = new JTextField();
        submitButton = new JButton("Kirim Jawaban");
        scoreLabel = new JLabel("Skor: 0", JLabel.CENTER);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setForeground(Color.GREEN);

        timerLabel = new JLabel("Waktu: 30 detik", JLabel.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel.setForeground(Color.RED);

        submitButton.addActionListener(e -> checkAnswer());

        JPanel gamePanel = new JPanel(new GridLayout(4, 1, 10, 10));
        gamePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        gamePanel.add(questionLabel);
        gamePanel.add(answerField);
        gamePanel.add(submitButton);
        gamePanel.add(scoreLabel);

        setLayout(new BorderLayout());
        add(gamePanel, BorderLayout.CENTER);
        add(timerLabel, BorderLayout.SOUTH);
    }

    // Metode untuk memulai permainan
    private void startGame(int difficultyLevel, int gameTime) {
        this.difficulty = difficultyLevel;
        this.timeLeft = gameTime;
        this.score = 0;
        getContentPane().removeAll();
        setupGame();
        generateQuestion();

        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeLeft--;
                timerLabel.setText("Waktu: " + timeLeft + " detik");

                if (timeLeft <= 0) {
                    timer.stop();
                    int restart = JOptionPane.showConfirmDialog(
                            null,
                            "Waktu habis! Skor akhir Anda: " + score + "\nIngin bermain lagi?",
                            "Permainan Selesai",
                            JOptionPane.YES_NO_OPTION
                    );
                    if (restart == JOptionPane.YES_OPTION) {
                        setupMenu();
                        repaint();
                        revalidate();
                    } else {
                        System.exit(0);
                    }
                }
            }
        });
        timer.start();
        repaint();
        revalidate();
    }

    // Metode untuk menghasilkan soal acak
    private void generateQuestion() {
        Random random = new Random();
        int num1 = random.nextInt(difficulty) + 1;
        int num2 = random.nextInt(difficulty) + 1;
        int operator = random.nextInt(4);

        switch (operator) {
            case 0:
                questionLabel.setText(num1 + " + " + num2 + " = ?");
                correctAnswer = num1 + num2;
                break;
            case 1:
                questionLabel.setText(num1 + " - " + num2 + " = ?");
                correctAnswer = num1 - num2;
                break;
            case 2:
                questionLabel.setText(num1 + " * " + num2 + " = ?");
                correctAnswer = num1 * num2;
                break;
            case 3:
                num1 = num1 * num2;
                questionLabel.setText(num1 + " / " + num2 + " = ?");
                correctAnswer = num1 / num2;
                break;
        }
    }

    // Metode untuk memeriksa jawaban
    private void checkAnswer() {
        try {
            int userAnswer = Integer.parseInt(answerField.getText().trim());
            if (userAnswer == correctAnswer) {
                score += 10;
                scoreLabel.setText("Skor: " + score);
                scoreLabel.setForeground(Color.GREEN);
            } else {
                scoreLabel.setForeground(Color.RED);
                JOptionPane.showMessageDialog(
                        this,
                        "Jawaban Salah! Jawaban yang benar adalah: " + correctAnswer,
                        "Hasil",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            answerField.setText("");
            generateQuestion();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Masukkan angka yang valid!",
                    "Kesalahan Input",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MathQuiz quiz = new MathQuiz();
            quiz.setDefaultCloseOperation(EXIT_ON_CLOSE);
            quiz.setSize(400, 400);
            quiz.setLocationRelativeTo(null);
            quiz.setVisible(true);
        });
    }
}
